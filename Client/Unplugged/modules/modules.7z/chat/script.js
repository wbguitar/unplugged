function UnpChat(htmlCont)
{
	var _cObj = new UnpModule('unpchat');

	_cObj.chatDisplay = document.createElement('div');
	$(_cObj.chatDisplay).addClass('unpchat-cont').html(
		'<div class="unpchat-message-log"></div>' +
		'<div class="unpchat-message-input"><input type="text"/></div>');
		
	$(_cObj.chatDisplay).find('.unpchat-message-input input').bind('keyup', function (evtObj) {
		if(evtObj.keyCode == '13')
		{
			_cObj.chatInput(this.value);
			$(this).val('');
		}
	});
	
	$(htmlCont).append(_cObj.chatDisplay);
	
	_cObj.handleAction = function (actionName, actionData)
	{
		switch(actionName)
		{
			case 'message':
			{
				var _msgLog = $(_cObj.chatDisplay).find('.unpchat-message-log')[0];
				
				var _cMsgElem = document.createElement('div');
				var _msgColor = actionData.color;
				
				$(_cMsgElem).addClass('unpchat-message').css('color', _msgColor).html(
					'<div class="unpchat-from">' + actionData.from + '</div>' +
					'<div class="unpchat-to">' + actionData.to + '</div>' +
					'<div class="unpchat-text">' + actionData.text + '</div>');

					$(_msgLog).append(_cMsgElem);
				_msgLog.scrollTop = _msgLog.scrollHeight;
			}
			break;
			case 'sysmsg':
			{
				var _msgLog = $(_cObj.chatDisplay).find('.unpchat-message-log')[0];
				
				var _cMsgElem = document.createElement('div');
				var _msgColor = actionData.color;
				
				$(_cMsgElem).addClass('unpchat-message').addClass('unpchat-sysmsg').html(
					'<div class="unpchat-text">' + actionData.text + '</div>' +
					'</div>');
					
					$(_msgLog).append(_cMsgElem);
				_msgLog.scrollTop = _msgLog.scrollHeight;
			}
			break;
		}
	}
	
	_cObj.chatInput = function (textVal)
	{
		var _umpMsg = new UnpMessage();
		_umpMsg.addAction(this.modName, 'message', { 'to': 'all', 'text': textVal });
		_umpMsg.send();
	}
}