function UnpAuth(htmlCont)
{
	var _cObj = new UnpModule('unpauth');

	_cObj.authDisplay = document.createElement('div');
	$(_cObj.authDisplay).addClass('unpauth-cont').html(
		'<div class="unpauth-login-desc">Login</div>' +
		'<div class="unpauth-login-input"><input type="text"/></div>' +
		'<div class="unpauth-logout">Logout</div>');
		
	$(_cObj.authDisplay).find('.unpauth-login-input input').bind('keyup', function (evtObj) {
		if(evtObj.keyCode == '13')
		{
			_cObj.authLogin(this.value);
			$(this).val('');
		}
	});
	
	$(_cObj.authDisplay).find('.unpauth-logout').bind('click', function (evtObj) {
		_cObj.authLogout(this.value);
	});
	
	$(htmlCont).append(_cObj.authDisplay);
	
	_cObj.handleAction = function (actionName, actionData)
	{
		switch(actionName)
		{
			case 'login-result':
			{
				UnpWarning.LoadingSplashHide();
				
				if(actionData['status'] == 'ok')
				{
					$(_cObj.authDisplay).parent().addClass('unpauth-login-ok');
				}
			}
			break;
			case 'logout-result':
			{
				UnpWarning.LoadingSplashHide();
				
				if(actionData['status'] == 'ok')
				{
					document.location.reload();
				}
			}
			break;
		}
	}
	
	_cObj.authLogin = function (textVal)
	{
		UnpWarning.LoadingSplashShow();
	
		var _umpMsg = new UnpMessage();
		_umpMsg.addAction(this.modName, 'login', { 'username': textVal });
		_umpMsg.send();
	}
	
	_cObj.authLogout = function (textVal)
	{
		UnpWarning.LoadingSplashShow();
	
		var _umpMsg = new UnpMessage();
		_umpMsg.addAction(this.modName, 'logout', { });
		_umpMsg.send();
	}
}