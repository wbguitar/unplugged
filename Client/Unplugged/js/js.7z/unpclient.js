function UnpClientInit()
{
	var _queryServer = UnpUtils.getQueryStringParam('server');

    if(_queryServer == null)
    {
        //'ws://localhost:8080';
        console.log(document.location.href);
        window.ServerUrl = 'ws://' + document.location.hostname + ':8080';
    }
    else
    {
        window.ServerUrl = 'ws://' + _queryServer;
    }
	
	UnpInit();
	UnpAuth($('#unpauth-div')[0]);
	UnpChat($('#unpchat-div')[0]);
	UnpMoveIt($('#unpmoveit-div')[0]);
	
	UnpToolbar($('#unptoolbar-div')[0], [ 
		{ 'text': 'visual fx', 'menu': [
			{ 'text': 'stripe array', 'click': function () { 
					var _confObj = {};
					_confObj.startX = 0;
					_confObj.startY = 0;
					_confObj.endX = 0;
					_confObj.endY = 0;
					_confObj.color1 = 'rgba(120, 120, 120, 0.7)';
					_confObj.color2 = 'rgba(200, 200, 200, 0.5)';
					_confObj.stripeWidth = 60;
					_confObj.stripeNum = 5;
			
					var _cFx = new UnpVisualFx.StripeArray($('#unpmoveit-div canvas')[0]);
					_cFx.Config(_confObj);
					window._testVisualFx = _cFx;
				} 
			},
			{ 'text': 'bezier array', 'click': function () { 
					var _confObj = {};
					_confObj.startX = 0;
					_confObj.startY = 0;
					_confObj.endX = 0;
					_confObj.endY = 0;
					_confObj.colorFrom = UnpColor(180, 0, 100, 0.5);
					_confObj.colorTo = UnpColor(0, 0, 180, 0.5);
					_confObj.lineWidth = 3;
					_confObj.lineNum = 7;
			
					var _cFx = new UnpVisualFx.BezierArray($('#unpmoveit-div canvas')[0]);
					_cFx.Config(_confObj);
					window._testVisualFx = _cFx;
				} 
			},
			{ 'text': 'line array', 'click': function () { 
					var _confObj = {};
					_confObj.startX = 0;
					_confObj.startY = 0;
					_confObj.endX = 0;
					_confObj.endY = 0;
					_confObj.colorFrom = UnpColor(0, 0, 220, 0.5);
					_confObj.colorTo = UnpColor(220, 220, 250, 0.5);
					_confObj.lineWidth = 1;
					_confObj.lineNum = 7;
			
					var _cFx = new UnpVisualFx.LineArray($('#unpmoveit-div canvas')[0]);
					_cFx.Config(_confObj);
					window._testVisualFx = _cFx;
				} 
			},
			{ 'text': 'timed bezier', 'click': function () { 
					var _confObj = {};
					_confObj.startX = 0;
					_confObj.startY = 0;
					_confObj.endX = 0;
					_confObj.endY = 0;
					_confObj.lineColor = UnpColor(180, 0, 100, 0.5);
					_confObj.lineWidth = 3;
					_confObj.maxDist = 25;
			
					var _cFx = new UnpVisualFx.TimedBezier($('#unpmoveit-div canvas')[0]);
					_cFx.Config(_confObj);
					window._testVisualFx = _cFx;
				} 
			},
			{ 'text': 'timed bezier array', 'click': function () { 			
					var _fxArray = [];
			
					for(var i = 0; i < 9; i ++)
					{
						var _confObj = {};
						_confObj.startX = 0;
						_confObj.startY = 0;
						_confObj.endX = 0;
						_confObj.endY = 0;
						_confObj.lineColor = UnpColor(0, 180, 50, 0.3);
						_confObj.lineWidth = 1 + (i % 3);
						_confObj.maxDist = 10;
					
						var _cFx = new UnpVisualFx.TimedBezier($('#unpmoveit-div canvas')[0]);
						_cFx.Config(_confObj);
						
						_fxArray.push(_cFx);
					}
					
					window._testVisualFx = _fxArray;
				} 
			},
			{ 'text': 'timed bezier array (big)', 'click': function () { 			
					var _fxArray = [];
			
					for(var i = 0; i < 9; i ++)
					{
						var _confObj = {};
						_confObj.startX = 0;
						_confObj.startY = 0;
						_confObj.endX = 0;
						_confObj.endY = 0;
						_confObj.lineColor = UnpColor(100, 0, 0, 0.3);
						_confObj.lineWidth = 3 + (i % 3);
						_confObj.maxDist = 200;
					
						var _cFx = new UnpVisualFx.TimedBezier($('#unpmoveit-div canvas')[0]);
						_cFx.Config(_confObj);
						
						_fxArray.push(_cFx);
					}
					
					window._testVisualFx = _fxArray;
				} 
			}
		] },
		{ 'text': 'particle fx', 'menu': [
			{ 'text': 'explosion', 'click': function () { 			
					var _cFx = new UnpVisualFx.Explosion($('#unpmoveit-div canvas')[0]);
					
					window._testVisualFx = _cFx;
				} 
			},
			{ 'text': 'flame', 'click': function () { 			
					var _cFx = new UnpVisualFx.Flame($('#unpmoveit-div canvas')[0]);
					
					window._testVisualFx = _cFx;
				} 
			},
			{ 'text': 'swirl', 'click': function () { 			
					var _cFx = new UnpVisualFx.Swirl($('#unpmoveit-div canvas')[0]);
					
					window._testVisualFx = _cFx;
				} 
			},
			{ 'text': 'spiral', 'click': function () { 			
					var _cFx = new UnpVisualFx.Spiral($('#unpmoveit-div canvas')[0]);
					
					window._testVisualFx = _cFx;
				} 
			}
		] } ]);
}