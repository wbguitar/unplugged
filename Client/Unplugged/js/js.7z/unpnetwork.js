

function UnpInit()
{
	UnpWarning.LoadingSplashShow();
	$('body').addClass('unp-connection-closed');
	
	window.ModuleList = [];	
	window.BaseWebSocket = new WebSocket(window.ServerUrl);
	var _socketOpen = false;
	
	window.BaseWebSocket.onopen = function () {
		UnpWarning.LoadingSplashHide();
		console.log('Connection to ' + window.ServerUrl + ' is open');
		_socketOpen = true;
		$('body').addClass('unp-connection-open').removeClass('unp-connection-closed');
	};
	
	window.BaseWebSocket.onerror = function (evt) {
		console.log("Error");
	};
	
	window.BaseWebSocket.onmessage = function (evt) {
		var _recMessage = evt.data;
		console.log("Message received: " + _recMessage);
		
		var _objMessage = $.parseJSON(_recMessage);
		var _cUnpMessage = new UnpMessage();
		for(var i = 0; i < _objMessage.unp.length; i++)
		{
			var _cAction = _objMessage.unp[i];
			window.ModuleList[_cAction.module].handleAction(_cAction.action, _cAction.data);
		}
	};
	
	window.BaseWebSocket.onclose = function () {
		console.log('Connection to ' + window.ServerUrl + ' is closed');
		$('body').removeClass('unp-connection-open').addClass('unp-connection-closed');
		
		if(!_socketOpen)
		{
			UnpWarning.LoadingSplashHide();
		}
		
		_socketOpen = false;
		
		UnpWarning.Alert('Connection to server failed. Press "OK" to try again.', function () { document.location.reload(); });
	};
	
	window.BaseWebSocket._sendBASE = window.BaseWebSocket.send;
	
	window.BaseWebSocket.send = function (sendMessage) {
		console.log('Sending message: ' + sendMessage);
		
		window.BaseWebSocket._sendBASE(sendMessage);
	};
}

function UnpMessage()
{
	var _cObj = {};
	_cObj.actionList = [];
	
	_cObj.addAction = function (modName, actionName, actionData)
	{
		this.actionList.push({ 'module': modName, 'action': actionName, 'data': actionData });
	}
	
	_cObj.send = function () {
		var _messageObj= {}
		_messageObj.unp = this.actionList;
		window.BaseWebSocket.send(JSON.stringify(_messageObj));
	};
	
	return _cObj;
}

function UnpModule(modName)
{
	var _cObj = {};
	_cObj.modName = modName;
	window.ModuleList[modName] = _cObj;
	
	_cObj.handleAction = function(actionName, actionData)
	{
	};
	
	return _cObj;
}