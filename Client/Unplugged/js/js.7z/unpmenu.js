function UnpToolbar(htmlCont, menuData)
{
	var _contDiv = document.createElement('div');
	$(_contDiv).addClass('unptoolbar-cont').addClass('unptoolbar-cont-closed');
	
	var _isWellOutTimer = null;
	
	$(_contDiv).bind('mouseover', function () {
		$(_contDiv).removeClass('unptoolbar-cont-closed');
		
		if(_isWellOutTimer != null)
		{
			window.clearTimeout(_isWellOutTimer);
			_isWellOutTimer = null;
		}		
	});
	
	$(_contDiv).bind('mouseout', function () {		
		if(_isWellOutTimer != null)
		{
			window.clearTimeout(_isWellOutTimer);
		}
		
		_isWellOutTimer = window.setTimeout(function () {
			$(_contDiv).addClass('unptoolbar-cont-closed');
		}, 500);
	});
	
	$(menuData).each(function () {
		var _cButton = document.createElement('div');
		$(_cButton).addClass('unptoolbar-button').html('<span class="unptoolbar-button-text">' + this.text + '</span>');
		
		if(this.click != null) 
		{
			$(_cButton).bind('click', this.click);
		}
		
		if(this.menu != null) 
		{
			var _cMenuCont = document.createElement('div');
			$(_cMenuCont).addClass('unptoolbar-button-menu');
			
			$(this.menu).each(function () {
				var _cMenuElement = document.createElement('div');
				
				$(_cMenuElement).html('<span>' + this.text + '</span>');
				$(_cMenuElement).addClass('unptoolbar-button-menu-element');
				
				if(this.click != null) 
				{
					$(_cMenuElement).bind('click', this.click);
				}
				
				$(_cMenuCont).append(_cMenuElement);
			});
			
			$(_cButton).bind('mouseover', function () { _UnpToolbarOpen(this); });
			$(_cButton).bind('mouseout', function () { _UnpToolbarClose(this); });
			
			$(_cButton).append(_cMenuCont);
		}
		
		$(_contDiv).append(_cButton);
	});
	
	$(htmlCont).append(_contDiv);
}

function _UnpToolbarOpen(targetElement)
{
	$(targetElement).parent().find('.unptoolbar-button-menu-open').removeClass('unptoolbar-button-menu-open');
	$(targetElement).addClass('unptoolbar-button-menu-open');
}

function _UnpToolbarClose(targetElement)
{
	$(targetElement).removeClass('unptoolbar-button-menu-open');
}

function _UnpToolbarToggle(targetElement)
{
	if($(targetElement).hasClass('unptoolbar-button-menu-open'))
	{
		_UnpToolbarClose(targetElement);
	}
	else
	{
		_UnpToolbarOpen(targetElement);
	}
}