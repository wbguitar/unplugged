var UnpUtils = {};

UnpUtils.randomHex = function (howMany) {
	if (howMany == null) howMany = 1;
	
	var _retVal = '';
	
	for(var i = 0; i < howMany; i++)
	{
		var _cChar = '';
		
		var _cNum = Math.floor(Math.random() * 16);
		if(_cNum < 10) _cChar += _cNum.toString();
		else
		{
			switch(_cNum)
			{
				case 10:
					_cChar += 'a';
					break;
				case 11:
					_cChar += 'b';
					break;
				case 12:
					_cChar += 'c';
					break;
				case 13:
					_cChar += 'd';
					break;
				case 14:
					_cChar += 'e';
					break;
				case 15:
					_cChar += 'f';
					break;
			}
		}
		
		_retVal += _cChar;
	}
	
	return _retVal;
}

UnpUtils.randomColor = function(colorFrom, colorTo)
{
	return UnpUtils.colorBetween(colorFrom, colorTo, Math.random());
}

UnpUtils.colorBetween = function (colorFrom, colorTo, colorPoint)
{
	if(colorFrom == null) colorFrom = new UnpColor(0, 0, 0, 1);
	if(colorTo == null) colorTo = new UnpColor(255, 255, 255, 1);
	if(colorPoint == null) colorPoint = 0.5;
	
	var _rDiff = colorTo.Red - colorFrom.Red;
	var _gDiff = colorTo.Green - colorFrom.Green;
	var _bDiff = colorTo.Blue - colorFrom.Blue;
	var _aDiff = colorTo.Alpha - colorFrom.Alpha;
	
	var _cRandom = Math.random();
	
	_rDiff = Math.round(_rDiff * colorPoint);
	_gDiff = Math.round(_gDiff * colorPoint);
	_bDiff = Math.round(_bDiff * colorPoint);
	_aDiff = _aDiff * colorPoint;
	
	return new UnpColor(colorFrom.Red + _rDiff, colorFrom.Green + _gDiff, colorFrom.Blue + _bDiff, colorFrom.Alpha + _aDiff);
}

UnpUtils.getQueryStringParam = function(paramName) {
	var _qStringMatch = document.location.search.match(new RegExp(paramName + '=([^&]*)'));

	if(_qStringMatch != null) _qStringMatch = _qStringMatch[1];
	return _qStringMatch;
}

UnpUtils.getRefreshRate = function () {
	return 20;
}